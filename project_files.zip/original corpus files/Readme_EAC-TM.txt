European Commission - Joint Research Centre (JRC)
Ralf Steinberger
24.10.2012

This zip file contains the EAC Translation Memory EAC-TM.
EAC-TM consists of translation units in 25 languages.
For details, go to http://langtech.jrc.ec.europa.eu/EAC-TM.html .
Usage conditions: The Commission's copright notice applies: http://ec.europa.eu/geninfo/legal_notices_en.htm.

