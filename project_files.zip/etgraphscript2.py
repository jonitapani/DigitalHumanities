from matplotlib import pyplot as plt
import numpy as np

labels = ["o.*õ","õ.*o","o.*ö","ö.*o","õ.*ö","ö.*õ"]
frequency = [10, 9, 3, 3, 0, 0]

x = np.arange(len(labels)) # the label locations
width = 0.35 # the width of the bars

fig, ax = plt.subplots()

ax.set_ylabel('Frequency')
ax.set_title('Occurrence of words with x.*y in specific order in the estonian corpus')
ax.set_xticks(x)
ax.set_xticklabels(labels)

pps = ax.bar(x - width/2, frequency, width, label='frequency')
for p in pps:
   height = p.get_height()
   ax.annotate('{}'.format(height),
      xy=(p.get_x() + p.get_width() / 2, height),
      xytext=(0, 3), # 3 points vertical offset
      textcoords="offset points",
      ha='center', va='bottom')

plt.show()
exit()