#First I extracted a dual fi-et corpus from a large file with multiple languages with an inbuilt tool.
#The output file was called fi-et.txt, which I modified by removing the header manually.
#
#Then I removed the data tags.
#
cat fi-et.txt | sed 's/<[^>]*>//g' >> corp.tmx
#
#Then I removed excess linebreaks.
#
cat corp.tmx | sed '/^$/d' >> corp2.tmx
#
#Then I tried to split the supposedly line-by-line translation with the following commands:
#
#	awk 'NR%2==1' corp2.tmx > ficorp1.tmx
#	awk 'NR%2==0' corp2.tmx > etcorp1.tmx
#
#For some reason the language changes twice in the middle of these files if split this way here. Why?
#
#The expected format in corp2.tmx is:
#
#	FINNISH SENTENCE 1.\n
#	ESTONIAN SENTENCE 1.\n
#	FINNISH SENTENCE 2.\n
#	ESTONIAN SENTENCE 2.\n
#	FINNISH SENTENCE 3.\n
#	ESTONIAN SENTENCE 3.\n
#
read -p "Here the data has a non-systematic error. Correct the error from corp2.tmx by removing line 118 (excess space and linebreak) manually, and after that remove the excess linebreak and add a space between lines 1409 and 1410. After fixing these manually, press enter to continue with the script."
#
#Here I found an error. on line 118 there was an excess line break like so:
#
#	FINNISH SENTENCE 59.\n
#	 \n
#	ESTONIAN SENTENCE 59.
#
#Our sed command was not able to remove this, as there was a space between two line breaks and thus sed did
#did not consider this an empty line. This was removed manually.
#On line 1409 there was also a similar error. A finnish sentence was split in two by an excess linebreak.
#This was also removed manually.
#
#	FINNISH SENTENCE 704.\n
#	FINNISH SENTENCE 704 continues.\n
#	ESTONIAN SENTENCE 704.\n
#
#The aforementioned issues were corrected manually. The issue was not a systematic one, and sed is meant to 
#work between linebreaks, and thus manual corrections were more efficient here.
#
#After the fixes I tried again.
#
awk 'NR%2==1' corp2.tmx > ficorp1.tmx
awk 'NR%2==0' corp2.tmx > etcorp1.tmx
#
#Checked, the files are now split correctly.
#
#
#
#Here I change all special symbols into commas and trunctuate them into one comma, if repeated.
#
cat ficorp1.tmx | tr -sc '[:alnum:]' ',' >> ficorp2.tmx
cat etcorp1.tmx | tr -sc '[:alnum:]' ',' >> etcorp2.tmx
#
#Then I change all numbers into commas and trunctuate them into one comma, if repeated.
#
cat ficorp2.tmx | tr -s '[:digit:]' ',' >> ficorp3.tmx
cat etcorp2.tmx | tr -s '[:digit:]' ',' >> etcorp3.tmx
#
#Just for future convenience, here I convert the files into .csv at this stage and save them as new files.
#
cat ficorp3.tmx >> ficorp.csv
cat etcorp3.tmx >> etcorp.csv
#
#All capital letters are change into lowercase
cat ficorp3.tmx | tr '[:upper:]' '[:lower:]' >> ficorp4.tmx
cat etcorp3.tmx | tr '[:upper:]' '[:lower:]' >> etcorp4.tmx
#
#To make sure sed works properly and to make the file more easy to manipulate for our purposes, all commas 
#are changed to linebreaks 
#
cat ficorp4.tmx | tr ',' '\n' >> ficorp5.tmx
cat etcorp4.tmx | tr ',' '\n' >> etcorp5.tmx
#
#Non-needed one-letter lines are removed, as one-letter words do not exist in Estonian or Finnish
cat etcorp5.tmx | sed '/^.$/d' > et.tmx 
cat ficorp5.tmx | sed '/^.$/d' > fi.tmx
#
#
#
#Pre-processing finally done. Now we can actually start calculating what we wanted to know.
#
#
wc -l et.tmx
#
echo "^ In the estonian corpus we have this many words / lines in total"
#
wc -l fi.tmx
#
echo "^ In the finnish corpus we have this many words / lines in total"
#
#
#
#
#Next we'll find out the total number of words including at least one letter o, ö or õ, in Estonian
#
echo "ESTONIAN CORPUS:"
egrep '[oöõ]' et.tmx > etoöõ.tmx
wc -l etoöõ.tmx
echo "^ In total, we have this many words that include at least one o, ö or õ in our estonian corpus"
#
#
#
#
#In estonian, how many words include at least one o?
#
egrep 'o' etoöõ.tmx -c
#
echo "^ This many words in the estonian corpus with at least one o."
#
#
#
#How about only o, i.e., no ö or õ?
#
egrep -v '[öõ]' etoöõ.tmx -c
#
echo "^ This many words in the estonian corpus with only o, not õ or ö"
#
#
#
#
#At least one ö:
#
egrep 'ö' etoöõ.tmx -c
#
echo "^ This many words in the estonian corpus with at least one ö"
#
#
#
#Only ö?
#
egrep -v '[oõ]' etoöõ.tmx -c
#
echo "^ This many words in the estonian corpus with only ö, not o or õ"
#
#
#
#At least one õ
#
egrep 'õ' etoöõ.tmx -c
#
echo "^ This many words in the estonian corpus with at least one õ"
#
#
#
#Only õ?
#
egrep -v '[oö]' etoöõ.tmx -c
#
echo "^ This many words in the estonian corpus with only õ, not o or ö" 
#
#
#
#
#Now the files are split even further to make it possible to include and exclude the things in the way we want.
#
egrep -v '[ö]' etoöõ.tmx > etoõ.tmx
egrep -v '[o]' etoöõ.tmx > etöõ.tmx
egrep -v '[õ]' etoöõ.tmx > etoö.tmx
#
#
#
#
#How about words with BOTH o AND ö? ö AND o?
#
egrep 'ö.*o' etoö.tmx -c
#
echo "^ This many words that include ö AND o in this order"
#
egrep 'o.*ö' etoö.tmx -c
#
echo "^ This many words that include o AND ö in this order"
#
egrep '(ö.*o|o.*ö)' etoö.tmx -c
#
echo "^ This many words that include ö AND o in any order"
#
#
#
#How about BOTH ö AND õ? õ AND ö?
#
egrep 'ö.*õ' etöõ.tmx -c
#
echo "^ This many words that include ö AND õ in this order"
#
egrep 'õ.*ö' etöõ.tmx -c
#
echo "^ This many words that include õ AND ö in this order"
#
egrep '(ö.*õ|õ.*ö)' etöõ.tmx -c
#
echo "^ This many words that include ö AND õ in any order"
#
#
#
#
#How about BOTH o AND õ? õ AND o?
#
egrep 'o.*õ' etoõ.tmx -c
#
echo "^ This many words that include o AND õ in this order"
#
egrep 'õ.*o' etoõ.tmx -c
#
echo "^ This many words that include õ AND o in this order"
#
egrep '(o.*õ|õ.*o)' etoõ.tmx -c
#
echo "^ This many words that include o AND õ in any order"
#
#
#
#
#
#How about words that include all three letters in any combination? Are there any?
#Since there were no words that include both ö and õ, the corpus can't include words that would include all three.
#
#If one wants to check for that, however, they can compare the calcs we did on the pair-subsets, run the same commands on
#the whole etoöõ.tmx subset, substract the pair subset sums from the whole subset's sums and see if there's any remaining.
#One could also run the following command to check for all permutations in one swoop:
#
egrep '(o.*ö.*õ|o.*õ.*ö|ö.*õ.*o|ö.*o.*õ|õ.*o.*ö|õ.*ö.*o)' etoöõ.tmx -c
#
echo "^ This many words that include at least one o, ö and õ in the estonian corpus"
#
#
#
#
#
#Now to the finnish corpus.
echo "FINNISH CORPUS:"
#
#Luckily, finnish language does not use the letter õ at all, which makes our job considerably easier.
#
egrep '[oö]' fi.tmx > fioö.tmx
wc -l fioö.tmx
#
echo "^ This many words with at least one o, ö, or both, in the finnish corpus"
#The finnish corpus includes 1860 words with at least one o, ö or both.
#
#
#How about both o and ö?
egrep 'o.*ö' fioö.tmx -c
#
echo "^ This many words with both o and ö in this order"
#
egrep 'ö.*o' fioö.tmx -c
#
echo "^ This many words with both ö and o in this order"
#
egrep '(o.*ö|ö.*o)' fioö.tmx -c
#
echo "^ This many words with both o and ö in any order"
#
#
#How about only o?
egrep -v '[ö]' fioö.tmx -c
#
echo "^ This many words with only an o, not an ö"
#
#
#How about only an ö?
egrep -v '[o]' fioö.tmx -c
#
echo "^ This many words with only an ö, not an o"
#Let's remove the files that are now unneeded
read -p "Should the created files be deleted (y/n)?" CONT
if [ "$CONT" = "y" ]; then
  echo "removing the created and analyzed files";
  rm corp.tmx corp2.tmx
  rm etcorp1.tmx etcorp2.tmx etcorp3.tmx etcorp4.tmx etcorp5.tmx
  rm ficorp1.tmx ficorp2.tmx ficorp3.tmx ficorp4.tmx ficorp5.tmx
  rm etoö.tmx etoõ.tmx etöõ.tmx etoöõ.tmx 
  rm fioö.tmx
  rm et.tmx fi.tmx 
  rm etcorp.csv
  rm ficorp.csv
else
  echo "leaving files alone";
fi
#
#
#