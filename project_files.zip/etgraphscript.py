from matplotlib import pyplot as plt
import numpy as np

labels = ["all words", "o/ö/õ", "has o", "only o", "has õ", "only õ", "has ö", "only ö", "o & õ", "o & ö", "ö & õ", "all 3"]
frequency = [4599, 1675, 1448, 1423, 223, 204, 29, 23, 19, 6, 0, 0]

x = np.arange(len(labels)) # the label locations
width = 0.35 # the width of the bars

fig, ax = plt.subplots()

ax.set_ylabel('Frequency')
ax.set_title('Occurrence of words with x in the estonian corpus')
ax.set_xticks(x)
ax.set_xticklabels(labels)

pps = ax.bar(x - width/2, frequency, width, label='frequency')
for p in pps:
   height = p.get_height()
   ax.annotate('{}'.format(height),
      xy=(p.get_x() + p.get_width() / 2, height),
      xytext=(0, 3), # 3 points vertical offset
      textcoords="offset points",
      ha='center', va='bottom')

plt.show()
exit()